package com.cs260.zhuosi.zsrepresent;

/**
 * Created by Zhuosi on 3/9/16.
 */
public interface AsyncResponse {
    void processFilnish(Object output);
}
